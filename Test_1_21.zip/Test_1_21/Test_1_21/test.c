#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>

//int my_strlen(char* str)
//{
//	if (*str != '\0')
//		return 1 + my_strlen(str + 1);
//	else
//		return 0;
//}
//
//int main()
//{
//	char arr[] = "bit";
//	//int len = strlen(arr); //���ַ����ĳ���
//	//prntf("%d\n",len);
//
//	//ģ��ʵ����һ��strlen����
//	int len = my_strlen(arr); //arr
//	printf("len = %d\n", len);
//	return 0;
//}

//int Fac2(int n)
//{
//	if (n <= 1)
//		return 1;
//	else
//		return n*Fac2(n - 1);
//}
//
//int main()
//{
//	//��n�Ľ׳�
//	int n = 0;
//	int ret = 0;
//	scanf("%d", &n);
//	ret = Fac2(n);
//	printf("%d\n", ret);
//	return 0;
//}

//쳲�������

int Fib(int n)
{
	int a = 1;
	int b = 1;
	int c = 0;
	while (n > 2)
	{
		c = a + b;
		a = b;
		b = c;
		n--;
	}
	return c;
}

int main()
{
	int n = 0;
	int ret = 0;
	scanf("%d", &n);
	//TDD - ������������
	ret = Fib(n);
	printf("ret = %d\n", ret);
	return 0;
}